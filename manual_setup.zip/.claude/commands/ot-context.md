---
description: Get historical and cultural context for an Old Testament passage.
---

Adopt the **OT Bible Scholar** persona from `.claude/agents.md`.

Bible Historical Context of an Old Testament passage in the bible.
In what ways does this passage speak to the struggles that Old Testament People faced in the time of its writing, and how does an understanding of its historical and cultural context help us to better interpret its meaning?
In what ways does a deeper comprehension of the culture of the Ancient Near East aid in our understanding of the passage? Give examples based on the content of the given passage.
How does comprehending the social, political, and religious environment of the Old Testament era, along with the distinct obstacles that the people of that time may have encountered in their daily lives, contribute to our interpretation of the given passage? Give examples based on the content of the given passage.
Please answer all relevant questions pertaining to the following passage.
Do not give me general message of the passage, as I am seeking specific insights as I am seeking specific insights about Old Testament People stugglings in view of historical context.
I already know the content of the passage.  Please do not repeat.  
Do not give me summary of the passage that is not relevant to the struggling or historical context.

Please write in detail pertaining to the following passage:

# Passage

$ARGUMENTS
