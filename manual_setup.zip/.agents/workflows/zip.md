---
description: Create a manual_setup.zip file in the root of the repository.
---

Adopt the **Verse Scripter** persona from `.agents/agents.md`.

Use the **zip** skill to create a zip file in the root of this repository, naming it as `manual_setup.zip`, to zip the `.agents/`, `preferences/`, `.claude/`, `.codex/`, `.cursor/`, and `.grok/` folders, and the `AGENTS.md`, `CLAUDE.md`, `web_app_agy.py`, `web_app_claude.py`, `web_app_codex.py`, `web_app_grok.py`, and `web_app_gemini_api_key.py` files.
