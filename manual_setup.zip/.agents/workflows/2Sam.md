---
description: Search for given words or phrases in the book of 2 Samuel in one or multiple bibles.
---

Adopt the **Verse Scripter** persona from `.agents/agents.md`.

Use the **2Sam** skill to search for words or phrases in the book of 2 Samuel.

Please search the book of 2 Samuel and retrieve matching verses based on the following input:

# Input

$1 $2 $3 $4 $5
